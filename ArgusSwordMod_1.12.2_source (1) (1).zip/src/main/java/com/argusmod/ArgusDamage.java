package com.argusmod;

import net.minecraft.entity.Entity;
import net.minecraft.util.EntityDamageSource;

/**
 * Урон от Меча Аргуса. Тип "player" - в чате смерти пишется как обычное убийство игроком.
 * Боевой обработчик такой урон не трогает (иначе была бы рекурсия).
 */
public class ArgusDamage extends EntityDamageSource {
    public ArgusDamage(Entity attacker, boolean ignoreArmor) {
        super("player", attacker);
        if (ignoreArmor) {
            setDamageBypassesArmor();
        }
    }
}
