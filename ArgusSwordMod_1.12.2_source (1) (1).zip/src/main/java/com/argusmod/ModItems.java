package com.argusmod;

import net.minecraft.item.Item;

public final class ModItems {
    public static final Item ARGUS_SWORD = new ItemArgusSword();

    private ModItems() {}
}
