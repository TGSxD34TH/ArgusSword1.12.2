package com.argusmod;

import net.minecraftforge.fml.common.Mod;

/**
 * Argus Sword - порт "Меча Аргуса" из Universally Shooter в Minecraft 1.12.2 (Forge).
 *
 * Обычный удар (ЛКМ)              : 2.5 сердца (5 HP)
 * Критический удар (ЛКМ в падении): 4.5 сердца (9 HP)
 * Зажатый удар (ПКМ 5 секунд)     : 14 сердец (28 HP) - "Кара Аргуса"
 *
 * Регистрация предмета и обработка боя висят на @Mod.EventBusSubscriber,
 * поэтому в самом классе мода делать ничего не нужно.
 */
@Mod(modid = ArgusMod.MODID, name = ArgusMod.NAME, version = ArgusMod.VERSION, acceptedMinecraftVersions = "[1.12.2]")
public class ArgusMod {
    public static final String MODID = "argusmod";
    public static final String NAME = "Argus Sword";
    public static final String VERSION = "1.0.0";
}
