package com.argusmod;

import com.google.common.collect.Multimap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * Меч Аргуса.
 *
 *  ЛКМ                      - обычный удар / критический (см. CombatHandler)
 *  ПКМ, удерживать 5 секунд - заряд, затем мини-катсцена "Кара Аргуса" (2 с):
 *                             через ~0.8 с удар по конусу впереди на 14 сердец.
 *                             После удара оружие заблокировано, пока не отпустишь ПКМ.
 *  Отпустить ПКМ раньше     - заряд сбрасывается (как в игре).
 */
public class ItemArgusSword extends Item {

    // ---- урон (в HP; 1 сердце = 2 HP) ----
    public static final float DMG_NORMAL = 5.0F;   // 2.5 сердца
    public static final float DMG_CRIT   = 9.0F;   // 4.5 сердца
    public static final float DMG_HOLD   = 28.0F;  // 14 сердец

    // ---- параметры зажатого удара (20 тиков = 1 секунда) ----
    public static final int HOLD_TICKS    = 100;   // 5 секунд зарядки
    public static final int STRIKE_DELAY  = 16;    // удар через 0.8 с после старта катсцены
    public static final int CUTSCENE_TICKS = 40;   // длительность катсцены, 2 с
    public static final double HOLD_RANGE = 16.0D; // дальность "Кары"
    public static final double HOLD_CONE  = 1.1D;  // полуугол конуса, рад (~63 градуса)

    // ---- параметры обычного удара ----
    public static final double SWEEP_RANGE = 2.5D; // радиус дуги, как у swR() в игре
    public static final double SWEEP_ARC   = 0.95D;// полуугол дуги, рад (~54 градуса)

    private static final int MAX_USE = 72000;

    /** Состояние зарядки по игрокам (только сервер). */
    private static final Map<UUID, State> STATES = new HashMap<UUID, State>();

    private static class State {
        boolean started;   // катсцена началась
        boolean struck;    // удар нанесён - блок до отпускания ПКМ
        int startTick;
        double lx, ly, lz; // направление взгляда в момент старта катсцены
    }

    public ItemArgusSword() {
        setRegistryName(ArgusMod.MODID, "argus_sword");
        setUnlocalizedName(ArgusMod.MODID + ".argus_sword");
        setCreativeTab(CreativeTabs.COMBAT);
        setMaxStackSize(1);
    }

    // ------------------------------------------------------------------ атрибуты

    @Override
    public Multimap<String, AttributeModifier> getItemAttributeModifiers(EntityEquipmentSlot slot) {
        Multimap<String, AttributeModifier> map = super.getItemAttributeModifiers(slot);
        if (slot == EntityEquipmentSlot.MAINHAND) {
            // база игрока 1.0 + 4.0 = 5.0 (2.5 сердца); скорость 4.0 - 3.4 = 0.6 уд/с (пауза ~1.7 с, как в игре)
            map.put(SharedMonsterAttributes.ATTACK_DAMAGE.getName(),
                    new AttributeModifier(ATTACK_DAMAGE_MODIFIER, "Weapon modifier", DMG_NORMAL - 1.0D, 0));
            map.put(SharedMonsterAttributes.ATTACK_SPEED.getName(),
                    new AttributeModifier(ATTACK_SPEED_MODIFIER, "Weapon modifier", -3.4D, 0));
        }
        return map;
    }

    @Override
    public boolean canDestroyBlockInCreative(World world, BlockPos pos, ItemStack stack, EntityPlayer player) {
        return false;
    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        return true;
    }

    @Override
    public EnumRarity getRarity(ItemStack stack) {
        return EnumRarity.EPIC;
    }

    // ------------------------------------------------------------------ зажатие ПКМ

    @Override
    public int getMaxItemUseDuration(ItemStack stack) {
        return MAX_USE;
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (hand != EnumHand.MAIN_HAND) {
            return new ActionResult<ItemStack>(EnumActionResult.PASS, stack);
        }
        if (!world.isRemote) {
            STATES.put(player.getUniqueID(), new State());
        }
        player.setActiveHand(hand);
        return new ActionResult<ItemStack>(EnumActionResult.SUCCESS, stack);
    }

    @Override
    public void onUsingTick(ItemStack stack, EntityLivingBase living, int count) {
        if (!(living instanceof EntityPlayer) || living.world.isRemote) {
            return;
        }
        EntityPlayer p = (EntityPlayer) living;
        WorldServer ws = (WorldServer) p.world;
        State s = STATES.get(p.getUniqueID());
        if (s == null) {
            s = new State();
            STATES.put(p.getUniqueID(), s);
        }
        if (s.struck) {
            return; // заблокировано до отпускания ПКМ
        }
        int t = MAX_USE - count; // сколько тиков удерживается

        if (!s.started) {
            // ---------- фаза зарядки (5 секунд)
            if (t < HOLD_TICKS) {
                if (t >= 4) {
                    float q = t / (float) HOLD_TICKS;
                    Vec3d look = p.getLookVec();
                    ws.spawnParticle(EnumParticleTypes.FLAME,
                            p.posX + look.x * 0.9D, p.posY + 1.0D, p.posZ + look.z * 0.9D,
                            1 + (int) (q * 6.0F), 0.35D, 0.5D, 0.35D, 0.01D);
                    if (q > 0.5F) {
                        ws.spawnParticle(EnumParticleTypes.SMOKE_LARGE,
                                p.posX, p.posY + 0.2D, p.posZ, 2, 0.4D, 0.1D, 0.4D, 0.01D);
                    }
                    if (t % 20 == 0) { // писк раз в секунду, тон растёт
                        ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.BLOCK_NOTE_PLING,
                                SoundCategory.PLAYERS, 0.8F, 0.5F + (t / 20) * 0.25F);
                    }
                    if (t % 5 == 0) {
                        p.sendStatusMessage(new TextComponentString(
                                TextFormatting.RED + "" + (int) (q * 100.0F) + "%"), true);
                    }
                }
                return;
            }
            // ---------- заряд готов: старт мини-катсцены
            s.started = true;
            s.startTick = t;
            Vec3d look = p.getLookVec();
            s.lx = look.x;
            s.ly = look.y;
            s.lz = look.z;
            ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_ENDERDRAGON_GROWL,
                    SoundCategory.PLAYERS, 1.2F, 0.6F);
            p.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, CUTSCENE_TICKS, 6, false, false));
            p.sendStatusMessage(new TextComponentTranslation("message.argusmod.punish"), true);
        }
        if (t >= s.startTick + STRIKE_DELAY) {
            strike(p, s);
        }
    }

    @Override
    public void onPlayerStoppedUsing(ItemStack stack, World world, EntityLivingBase living, int timeLeft) {
        if (world.isRemote || !(living instanceof EntityPlayer)) {
            return;
        }
        State s = STATES.remove(living.getUniqueID());
        // катсцена уже началась - удар не отменить (как в игре)
        if (s != null && s.started && !s.struck && living.isEntityAlive()) {
            strike((EntityPlayer) living, s);
        }
    }

    // ------------------------------------------------------------------ "Кара Аргуса"

    private void strike(EntityPlayer p, State s) {
        s.struck = true;
        WorldServer ws = (WorldServer) p.world;
        Vec3d look = new Vec3d(s.lx, s.ly, s.lz).normalize();
        Vec3d eye = p.getPositionEyes(1.0F);

        // визуал: огненная просека + взрывы вдоль удара
        for (double d = 1.0D; d <= HOLD_RANGE; d += 0.75D) {
            double x = eye.x + look.x * d, y = eye.y + look.y * d - 0.2D, z = eye.z + look.z * d;
            ws.spawnParticle(EnumParticleTypes.FLAME, x, y, z, 4, 0.4D, 0.4D, 0.4D, 0.03D);
            ws.spawnParticle(EnumParticleTypes.LAVA, x, y, z, 1, 0.5D, 0.5D, 0.5D, 0.0D);
            if (((int) (d / 0.75D)) % 3 == 0) {
                ws.spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, x, y, z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            }
        }
        ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_GENERIC_EXPLODE,
                SoundCategory.PLAYERS, 1.6F, 0.6F);
        ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_LIGHTNING_THUNDER,
                SoundCategory.PLAYERS, 1.2F, 0.8F);

        // урон по конусу
        AxisAlignedBB box = p.getEntityBoundingBox().grow(HOLD_RANGE);
        List<EntityLivingBase> list = p.world.getEntitiesWithinAABB(EntityLivingBase.class, box);
        double cosCone = Math.cos(HOLD_CONE);
        int hits = 0;
        for (EntityLivingBase e : list) {
            if (!CombatHandler.canTarget(p, e)) {
                continue;
            }
            double dx = e.posX - eye.x, dy = e.posY + e.height * 0.5D - eye.y, dz = e.posZ - eye.z;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist > HOLD_RANGE + e.width) {
                continue;
            }
            double cos = dist < 1.0E-4D ? 1.0D : (dx * look.x + dy * look.y + dz * look.z) / dist;
            boolean inCone = cos >= cosCone || dist <= e.width * 0.5D + 0.6D;
            if (!inCone || !p.canEntityBeSeen(e)) {
                continue;
            }
            e.hurtResistantTime = 0; // "Кара" пробивает кадры неуязвимости
            if (e.attackEntityFrom(new ArgusDamage(p, true), DMG_HOLD)) {
                hits++;
                e.motionX += look.x * 1.2D;
                e.motionY += 0.4D;
                e.motionZ += look.z * 1.2D;
                e.velocityChanged = true;
                ws.spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, e.posX, e.posY + e.height * 0.5D, e.posZ,
                        1, 0.0D, 0.0D, 0.0D, 0.0D);
            }
        }
        if (hits > 0) {
            p.sendStatusMessage(new TextComponentTranslation("message.argusmod.hits", hits), true);
        }
    }

    // ------------------------------------------------------------------ подсказка

    @Override
    @SideOnly(Side.CLIENT)
    public void addInformation(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        tooltip.add(TextFormatting.GRAY + I18n.format("tooltip.argusmod.normal", "2.5"));
        tooltip.add(TextFormatting.GOLD + I18n.format("tooltip.argusmod.crit", "4.5"));
        tooltip.add(TextFormatting.DARK_RED + I18n.format("tooltip.argusmod.hold", "5", "14"));
    }
}
