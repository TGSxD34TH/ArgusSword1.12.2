package com.argusmod;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Обычный и критический удар Меча Аргуса.
 *
 * AttackEntityEvent    - считаем, критический ли удар (условия как у ванильного крита:
 *                        падение, не на земле, не на лестнице, не в воде, не спринт, полный замах),
 *                        и бьём по дуге вокруг цели (как слеш в игре).
 * LivingHurtEvent      - подменяем ванильный урон на фиксированный: 5 HP / 9 HP.
 */
@Mod.EventBusSubscriber(modid = ArgusMod.MODID)
public class CombatHandler {

    private static class Pending {
        final float damage;
        final long tick;
        Pending(float damage, long tick) {
            this.damage = damage;
            this.tick = tick;
        }
    }

    private static final Map<UUID, Pending> PENDING = new HashMap<UUID, Pending>();

    @SubscribeEvent
    public static void onAttack(AttackEntityEvent event) {
        EntityPlayer p = event.getEntityPlayer();
        if (p.world.isRemote) {
            return;
        }
        ItemStack held = p.getHeldItemMainhand();
        if (!(held.getItem() instanceof ItemArgusSword)) {
            return;
        }
        Entity target = event.getTarget();
        if (!target.canBeAttackedWithItem()) {
            return;
        }

        float str = p.getCooledAttackStrength(0.5F);
        boolean crit = str > 0.9F
                && p.fallDistance > 0.0F
                && !p.onGround
                && !p.isOnLadder()
                && !p.isInWater()
                && !p.isPotionActive(MobEffects.BLINDNESS)
                && !p.isRiding()
                && !p.isSprinting()
                && target instanceof EntityLivingBase;

        float base = crit ? ItemArgusSword.DMG_CRIT : ItemArgusSword.DMG_NORMAL;
        // недозаряженный замах слабее - как у ванильного оружия
        float dmg = base * (0.2F + str * str * 0.8F);

        PENDING.put(p.getUniqueID(), new Pending(dmg, p.world.getTotalWorldTime()));
        sweep(p, target, dmg);
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        DamageSource src = event.getSource();
        if (src instanceof ArgusDamage || !(src instanceof EntityDamageSource)
                || !"player".equals(src.getDamageType())) {
            return;
        }
        Entity attacker = src.getTrueSource();
        if (!(attacker instanceof EntityPlayer) || src.getImmediateSource() != attacker) {
            return;
        }
        EntityPlayer p = (EntityPlayer) attacker;
        if (p.world.isRemote || !(p.getHeldItemMainhand().getItem() instanceof ItemArgusSword)) {
            return;
        }
        Pending pend = PENDING.remove(p.getUniqueID());
        if (pend == null || pend.tick != p.world.getTotalWorldTime()) {
            return;
        }
        event.setAmount(pend.damage);
    }

    /** Дуга удара вокруг игрока: радиус 2.5, полуугол ~54 градуса. */
    private static void sweep(EntityPlayer p, Entity primary, float dmg) {
        Vec3d look = p.getLookVec();
        double h = Math.sqrt(look.x * look.x + look.z * look.z);
        if (h < 1.0E-4D) {
            return;
        }
        double lx = look.x / h, lz = look.z / h;
        double cosArc = Math.cos(ItemArgusSword.SWEEP_ARC);
        double r = ItemArgusSword.SWEEP_RANGE;

        List<EntityLivingBase> list = p.world.getEntitiesWithinAABB(EntityLivingBase.class,
                p.getEntityBoundingBox().grow(r, 1.0D, r));
        for (EntityLivingBase e : list) {
            if (e == primary || !canTarget(p, e)) {
                continue;
            }
            double dx = e.posX - p.posX, dz = e.posZ - p.posZ;
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d - e.width * 0.5D > r) {
                continue;
            }
            double cos = d < 1.0E-4D ? 1.0D : (dx * lx + dz * lz) / d;
            if (!(cos >= cosArc || d <= e.width * 0.5D + 0.4D) || !p.canEntityBeSeen(e)) {
                continue;
            }
            if (e.attackEntityFrom(new ArgusDamage(p, false), dmg)) {
                float yaw = p.rotationYaw * 0.017453292F;
                e.knockBack(p, 0.4F, MathHelper.sin(yaw), -MathHelper.cos(yaw));
            }
        }
        if (p.world instanceof WorldServer) {
            ((WorldServer) p.world).spawnParticle(EnumParticleTypes.SWEEP_ATTACK,
                    p.posX + lx * 1.5D, p.posY + p.height * 0.5D, p.posZ + lz * 1.5D, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        p.world.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP,
                SoundCategory.PLAYERS, 1.0F, 1.0F);
    }

    /** Можно ли бить это существо (свои питомцы, команда, чужие игроки без PvP, маркеры - нельзя). */
    public static boolean canTarget(EntityPlayer p, EntityLivingBase e) {
        if (e == p || !e.isEntityAlive() || e.isRidingOrBeingRiddenBy(p)) {
            return false;
        }
        if (e instanceof EntityArmorStand && ((EntityArmorStand) e).hasMarker()) {
            return false;
        }
        if (e instanceof EntityTameable && ((EntityTameable) e).isOwner(p)) {
            return false;
        }
        if (p.isOnSameTeam(e)) {
            return false;
        }
        if (e instanceof EntityPlayer && !p.canAttackPlayer((EntityPlayer) e)) {
            return false;
        }
        return true;
    }
}
